KatPlugin 1.2.3: C3 known-answer fixture.
